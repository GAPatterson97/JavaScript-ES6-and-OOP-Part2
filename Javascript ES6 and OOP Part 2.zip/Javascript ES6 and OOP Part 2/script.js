// Get references to HTML elements
const clubList = document.getElementById('club-list');
const searchInput = document.getElementById('search');
const clubDetailsContainer = document.getElementById('main');

// Attach an input event listener for the search input
searchInput.addEventListener('input', handleSearchInput);

// Initialize football club data and display all clubs
let clubData = footballClubs; 
displayClubs(footballClubs);


// Display football clubs in the club list
function displayClubs(clubs) {
    // Generate HTML for club cards and set it in the clubList element
    const clubCardsHTML = clubs.map(createClubCardHTML).join('');
    clubList.innerHTML = clubCardsHTML;
}

// Create HTML for a football club card
function createClubCardHTML(club) {
    return `
        <div class="club-card" onclick="handleClubClick(this);"><!-- Add onclick event -->
            <h2>${club.name}</h2>
            <img src="${club.image}" alt="${club.name} Image" style="width:100%; height:20vh;">
            <p><b>League: </b>${club.league}</p>
            <p><b>City: </b>${club.city}</p>
            <button onclick="viewClubPlayers('${club.name}'); event.stopPropagation();" style="width:100%;">View Players</button>
        </div>
    `;
}

// Handle clicking on a football club card
function handleClubClick(element) {
    const clickedClubCard = element;
    if (clickedClubCard) {
        // Get club name from HTML club card
        const clickedClubName = clickedClubCard.querySelector('h2').textContent;
        // Find club name and all details
        const selectedClub = clubData.find(club => club.name === clickedClubName);

        // call displayClubDetails to display all the details of selected club
        if (selectedClub) {
            displayClubDetails(selectedClub);
            //console.log(selectedClub); // Test code
        }
    }
}

// Display football club details
function displayClubDetails(club) {
    // The HTML of the selected club card
    const clubDetailsHTML = `
        <div id=club-details>
            <button onclick="window.location.reload();">Back</button>
            <h2>${club.name}</h2>
            <img src="${club.image}" alt="${club.name} Image" style="width:40vh; height:40vh;">
            <p><b>League:</b>  ${club.league}</p>
            <p><b>City:</b>  ${club.city}</p>
            <p><b>Stadium:</b>  ${club.stadium}</p>
            <button onclick="viewClubPlayers('${club.name}'); event.stopPropagation();">View Players</button>
            <p><b>Description:</b>  ${club.description}</p>
        </div>
    `;
    // Create the inner HTML of the selected club card
    clubDetailsContainer.innerHTML = clubDetailsHTML;
}

// Function to view club players
function viewClubPlayers(clubName) {
    // Find club name and all the players details
    const selectedClub = clubData.find(club => club.name === clubName);
    // Start the HTML of the selected club players
    let clubPlayersHTML = `
        <div id=club-details>
        <button onclick="window.location.reload();">Back</button>
        <h2>${selectedClub.name} Players</h2>
    `;
    // Add HTML to clubPlayersHTML for each player
    for(var i = 0; i < selectedClub.players.length; i++) {
        clubPlayersHTML += `
            <p><b>Name:</b>  ${selectedClub.players[i].name}</p>
            <p><b>Position:</b>  ${selectedClub.players[i].position}</p>
            <p><b>Number:</b>  ${selectedClub.players[i].number}</p>
            <p><b>Goals:</b>  ${selectedClub.players[i].goals}</p>
            <p><b>Assists:</b>  ${selectedClub.players[i].assists}</p>
            <hr>
        `;
    }
    // Close div tag to clubPlayersHTML
    clubPlayersHTML += `</div>`;
 // Create the final inner HTML for all the club players
 clubDetailsContainer.innerHTML = clubPlayersHTML;
}

// Handle search input and filter clubs
function handleSearchInput() {
    // Convert search term input to all lower case
    const searchTerm = searchInput.value.toLowerCase();
    // Filter all clubs that include search term
    const filteredClubs = clubData.filter(club => {
        // Create a string containing club details for searching
        const clubDataString = `${club.name} ${club.league} ${club.city}`.toLowerCase();
        return clubDataString.includes(searchTerm);
    });
    // Display all the filtered clubs to Homepage
    displayClubs(filteredClubs);
}